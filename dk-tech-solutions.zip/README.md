# DK Tech Solutions

This is the website for DK Tech Solutions, built with Next.js and Tailwind CSS.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

### Prerequisites

- Node.js (v14 or later)
- npm (v6 or later)

### Installing

1. Clone the repository:

