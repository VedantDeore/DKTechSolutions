/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['lh3.googleusercontent.com', 'raw.githubusercontent.com', 'encrypted-tbn0.gstatic.com', 'api.starlink.com', 'www.apple.com'],
  },
}

module.exports = nextConfig

